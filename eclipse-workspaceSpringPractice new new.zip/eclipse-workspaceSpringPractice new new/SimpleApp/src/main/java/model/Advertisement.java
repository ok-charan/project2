package model;

public class Advertisement {
	private int advertisementId;
	private String advertisementType;
	private float cost;
	public int getAdvertisementId() {
		return advertisementId;
	}
	public void setAdvertisementId(int advertisementId) {
		this.advertisementId = advertisementId;
	}
	public String getAdvertisementType() {
		return advertisementType;
	}
	public void setAdvertisementType(String advertisementType) {
		this.advertisementType = advertisementType;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	
	

}
