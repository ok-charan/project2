package controller;

import model.Advertisement;


public class AdvertisementController {
	
	
	String getAdvertisementpage(Advertisement aobj)
	{
		return null;
	}
	
	
	String displayAdvertisementDetails(Advertisement aobj)
	{
		return null;
	}
}
