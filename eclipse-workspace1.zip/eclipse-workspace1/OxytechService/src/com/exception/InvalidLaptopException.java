package com.exception;

public class InvalidLaptopException extends Exception{

	// Include a public Single argument Constructor and set the message through super class Constructor
	public InvalidLaptopException(String message) {
		super(message);
	}
}
