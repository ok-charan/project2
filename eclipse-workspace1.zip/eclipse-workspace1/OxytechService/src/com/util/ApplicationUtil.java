package com.util;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.exception.InvalidLaptopException;

public class ApplicationUtil {

	public static List<String> extractDetails(String[] input)throws InvalidLaptopException {
	    List<String> stringList = new ArrayList<String>();

	    // FILL THE CODE HERE
	    try {
	    	for(String x:input) {
	    		String[] arr=x.split(":");
	    		if(validateLaptopName(arr[1])) {
	    			stringList.add(x);
	    		}
	    	}
	    }
	    catch(InvalidLaptopException e) {
	    	System.out.println("Invalid laptop records: "+e.getMessage());
	    }
	    	
	   	 return stringList;
	}


	public static boolean validateLaptopName(String laptopName) throws InvalidLaptopException{
		
		// FILL THE CODE HERE
		if(laptopName.equalsIgnoreCase("Apple")||laptopName.equalsIgnoreCase("HP")||
				laptopName.equalsIgnoreCase("Dell")||laptopName.equalsIgnoreCase("Lenovo")||
				laptopName.equalsIgnoreCase("Acer")) {
	    			
	    			return true;
	    		}
	    		else
	    		{
	    			throw new InvalidLaptopException("Invalid laptop");
	    		}
	}

	public static java.util.Date stringToDateConverter(String stringDate) {
		
		// FILL THE CODE HERE
		java.util.Date date=null;
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
		try {
			
			date=dateFormat.parse(stringDate);
			return date;
		}
		catch(ParseException e) {
	        return null;
		}
	}
public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
	
	    // FILL THE CODE HERE
	
	    return new java.sql.Date(utDate.getTime());
	}	 
	 	  	  		    	  	      	      	 	

}