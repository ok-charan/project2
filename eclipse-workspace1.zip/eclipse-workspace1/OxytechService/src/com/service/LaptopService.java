package com.service;
import java.util.ArrayList;
import java.util.List;

import com.dao.LaptopDAO;
import com.exception.InvalidLaptopException;
import com.model.Laptop;
import com.util.ApplicationUtil;

public class LaptopService {

	public static List <Laptop> buildServiceList(List <String> serviceRecords) {

		List <Laptop> objectList = new ArrayList<Laptop>();
		
		// FILL THE CODE HERE
		for(String x:serviceRecords) {
			String arr[]=x.split(":");
			Laptop l=new Laptop(
					arr[0],arr[1],ApplicationUtil.stringToDateConverter(arr[2]),
					arr[3],arr[4],calculateBillAmount(arr[3],arr[4]));
			objectList.add(l);
		}
		
		return objectList;
	}

	public boolean addServiceList(String[] input) throws InvalidLaptopException	{

		// FILL THE CODE HERE
		
		List<String> list=ApplicationUtil.extractDetails(input);
		List<Laptop> laptop=buildServiceList(list);
		LaptopDAO l=new LaptopDAO();
		
			
		return l.insertServiceList(laptop)>0;
		}

	
	public static double calculateBillAmount(String rootIssue,String issueIntensity)
	{
		// FILL THE CODE HERE 
		double b=0;
		double c=0;
				
		switch(rootIssue.toUpperCase()) {
		case "SOFTWARE":
			b+=2000;
			break;
		case "DISPLAY":
		b+=5000;
		break;
		case "KEYBOARD":
		b+=1000;
		break;
		case "SOUND":
		b+=800;
		break;
		case "KEY":
		b+=500;
		break;
		default:
		break;
		
		}
		switch(issueIntensity.toUpperCase()) {
		case "LOW":
		c=b-(b*0.05);
		break;
		case "MID":
			c=b+(b*0.05);
			break;
		case "HIGH":
			c=b+(b*0.1);
			break;
		default:
			break;
		
		}
		return c;
	}

}

