<?php foreach ($context['options'] as $option) : ?>
    <?php echo $option->render(); ?>
<?php endforeach; ?>
