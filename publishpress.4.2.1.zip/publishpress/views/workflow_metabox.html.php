<div id="psppno-workflow-metabox" class="pure-g">

    <!-- Events -->
    <?php echo $context['section_event']; ?>

    <!-- Event Content -->
    <?php echo $context['section_event_content']; ?>

    <!-- Receiver -->
    <?php echo $context['section_receiver']; ?>

    <!-- Content -->
    <?php echo $context['section_content']; ?>

    <!-- Channel -->
    <?php echo $context['section_channel']; ?>

</div>
