Thank you for helping create great content with us.

This notification is to let you know the content "[psppno_post title]" was published.

The user who published the content is [psppno_actor display_name].

The URL of the content is [psppno_post permalink]
