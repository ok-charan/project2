Thank you for helping create great content with us.

This notification is to let you know that an editorial comment was added for "[psppno_post title]".

The user who commented is [psppno_actor display_name].

Comment:
[psppno_edcomment content]
