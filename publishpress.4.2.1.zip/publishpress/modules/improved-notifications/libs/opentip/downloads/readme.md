# Downloads

Choose the **one** file that suits your needs. If you don't intend to support IE8
(or include excanvas yourself) you don't need the `-excanvas` version.

You'll probably want the `.min.js` version unless you count on debugging Opentip.

## Generate downloads

To generate downloads you need to run `npm install` once from within the
root folder, and then `grunt js`.