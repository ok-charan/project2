package com.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.exception.InvalidPlayerRoleException;
import com.model.Player;

public class PlayerAssociation {
	
	List<Player> playerList = new ArrayList<>();
	String InvalidPlayerRoleException=null;

	
	public List<Player> getPlayerList() {
		return playerList;
	}

	public void setPlayerList(List<Player> playerList) {
		this.playerList = playerList;
	}

	public boolean validatePlayerRole(String playerRole) throws InvalidPlayerRoleException  {
	   if(playerRole.equals("Batsman") || playerRole.equals("Bowler")|| playerRole.equals("AllRounder"))
		   return true;
	   else
		   throw new InvalidPlayerRoleException("Player role is invalid");
	}
	
	public Player viewPlayerDetailsByPlayerId(String playerId) throws InvalidPlayerRoleException {
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {	 	  	      	 		     	     	        	 	
			for(Player p : playerList){
				if(p.getPlayerId()==playerId)
					return p;
			}
			throw new InvalidPlayerRoleException("Player ID is invalid");	
		}
	}
	
	public List<Player> viewPlayerDetailsByPlayerRole(String playerRole) throws InvalidPlayerRoleException {
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {
			List<Player> result = new ArrayList<>();
			for(Player p : playerList){
				if(p.getPlayerRole().equals(playerRole))
					result.add(p);
			}
			return result;	
		}
	}
	
	public Map<String,List<Player>> viewPlayerDetailsPlayerRoleWise() throws InvalidPlayerRoleException {
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {
			Map<String,List<Player>> result = new LinkedHashMap<>();
			
			for(Player p : playerList){
				if(!result.containsKey(p.getPlayerRole())){
					result.put(p.getPlayerRole(),new ArrayList<Player>());
				}
				List<Player> temp=result.get(p.getPlayerRole());
				temp.add(p);
				result.put(p.getPlayerRole(), temp);			
			}	 	  	      	 		     	     	        	 	
			return result;
		}
	}
	
	public  Map<String,Integer> countTotalNumberOfPlayersForEachPlayerRole() throws InvalidPlayerRoleException {
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {
			Map<String,Integer> result = new LinkedHashMap<>();
			
			for(Player p : playerList){
				if(!result.containsKey(p.getPlayerRole())){
					result.put(p.getPlayerRole(),1);
				}
				else
				{
					int temp=result.get(p.getPlayerRole());					
					result.put(p.getPlayerRole(), temp+1);
				}				
			}
			return result;
		}
	}	
	public List<String> findPlayersWithBattingAverageGreaterThanOrEqualTo50() throws InvalidPlayerRoleException{
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {
			List<String> result=new ArrayList<String>();
			for(Player p : playerList){
				if(p.getBattingAverage()>=50)
					result.add(p.getPlayerName());
			}
			return result;	
			
		}	 	  	      	 		     	     	        	 	
	}
		
	public double findLowestBowlingEconomy() throws InvalidPlayerRoleException{
		if(playerList.size()==0){
			throw new InvalidPlayerRoleException("Player list is empty");
		}
		else {
			List<Double> bowEconomy=new ArrayList<Double>();
			for(Player p : playerList)
				bowEconomy.add(p.getBowlingEconomy());
				Object res[]=bowEconomy.toArray();
				Arrays.sort(res);
				return (double)(res[0]);

			
			
		}
		
	}
	
}



	 	  	      	 		     	     	        	 	
