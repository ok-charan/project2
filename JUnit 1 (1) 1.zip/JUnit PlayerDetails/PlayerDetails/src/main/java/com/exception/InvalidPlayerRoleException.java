package com.exception;

public class InvalidPlayerRoleException extends Exception {

	public InvalidPlayerRoleException(String message) {
		super(message);
	}
}

