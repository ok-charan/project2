package com.model;


public class Player {
	String playerId;
	String playerName;
	String playerRole;
	double battingAverage;
	double bowlingEconomy;
	public String getPlayerId() {
		return playerId;
	}
	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getPlayerRole() {
		return playerRole;
	}
	public void setPlayerRole(String playerRole) {
		this.playerRole = playerRole;
	}
	public double getBattingAverage() {
		return battingAverage;
	}
	public void setBattingAverage(double battingAverage) {
		this.battingAverage = battingAverage;
	}
	public double getBowlingEconomy() {
		return bowlingEconomy;
	}
	public void setBowlingEconomy(double bowlingEconomy) {	 	  	      	 		     	     	        	 	
		this.bowlingEconomy = bowlingEconomy;
	}
	public Player(String playerId, String playerName, String playerRole, double battingAverage, double bowlingEconomy) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerRole = playerRole;
		this.battingAverage = battingAverage;
		this.bowlingEconomy = bowlingEconomy;
	}
	
}