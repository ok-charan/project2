package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.util.PlayerAssociation;
import com.exception.InvalidPlayerRoleException;
import com.model.Player;

public class PlayerAssociationTest {
	
	private static List<Player> playerList = new ArrayList<>();
	private static PlayerAssociation pObj;
	
	
	@BeforeAll
	public static void setUp() throws Exception {
		pObj = new PlayerAssociation();
		Player p1=new Player("1", null,"Batsman", 60.0, 5.0);
		Player p2=new Player("2", null,"Bowler", 38.0, 1.0);
		Player p3=new Player("3", null,"AllRounder", 49.0, 8.0);
		Player p4=new Player("4", null,"Batsman", 37.0, 9.0);
		pObj=new PlayerAssociation();
		playerList.add(p1);
		playerList.add(p2);
		playerList.add(p3);
		playerList.add(p4);
		pObj.setPlayerList(playerList);
		//Create few  objects for Player class and add to a list.
		//Set that list to the playerList using the setPlayerList method in PlayerAssociation class 
	}

		
	
	//Test the validatePlayerRole method when the playerRole is Batsman
	@Test
	public void test11ValidatePlayerRoleWhenBatsman()throws InvalidPlayerRoleException{
		assertEquals(true,pObj.validatePlayerRole("Batsman"));
		//Fill the code here
	}
	
	//Test the validatePlayerRole method when the playerRole is Bowler
	@Test
	public void test12ValidatePlayerRoleWhenBowler()throws InvalidPlayerRoleException{
		//Fill the code here
		assertEquals(true,pObj.validatePlayerRole("Bowler"));
	}
	
	//Test the validatePlayerRole method when the playerRole is AllRounder
	@Test
	public void test13ValidatePlayerRoleWhenAllRounder()throws InvalidPlayerRoleException{	 	  	      	 		     	     	        	 	
		//Fill the code here
     assertEquals(true,pObj.validatePlayerRole("AllRounder"));
	}
	
	//Test the validatePlayerRole method when the playerRole is invalid
	@Test
	public void test14ValidatePlayerRoleWhenInvalid() {
		//Fill the code here
		assertThrows(InvalidPlayerRoleException.class,()->pObj.validatePlayerRole("real"));
	}
	
	//Test the viewPlayerDetailsByPlayerId method when the playerId is valid
	@Test
	public void test15ViewPlayerDetailsByPlayerIdWhenValid() throws InvalidPlayerRoleException{
		//Fill the code here
       assertEquals("1",pObj.viewPlayerDetailsByPlayerId("1").getPlayerId());
	}
	
	//Test the viewPlayerDetailsByPlayerId method when the playerId is invalid
	@Test
	public void test16ViewPlayerDetailsByPlayerIdWhenInvalid() {
		//Fill the code here
		assertThrows(InvalidPlayerRoleException.class,()->pObj.viewPlayerDetailsByPlayerId("5"));
	}
	
	//Test the viewPlayerDetailsByPlayerId method 
	@Test
	public void test17ViewPlayerDetailsByPlayerRole() throws InvalidPlayerRoleException {
		//Fill the code here
		assertEquals("1",pObj.viewPlayerDetailsByPlayerId("1").getPlayerId());
	}
    
	//Test the viewPlayerDetailsPlayerRoleWise method 
	@Test
	public void test18ViewPlayerDetailsPlayerRoleWise() throws InvalidPlayerRoleException {
		//Fill the code here
   assertEquals(1,pObj.viewPlayerDetailsPlayerRoleWise().get("Bowler").size());
	}
	
	//Test the countTotalNumberOfPlayersForEachPlayerRole method 
	@Test
	public void test19TotalCountOfPlayersForEachPlayerRole() throws InvalidPlayerRoleException{
		//Fill the code here
		assertEquals(1,pObj.countTotalNumberOfPlayersForEachPlayerRole().get("Bowler"));
	}	 	  	      	 		     	     	        	 	
	
	//Test the findPlayersWithBattingAverageGreaterThanOrEqualTo50 method 
	@Test
  	public void test20FindPlayersWithBattingAverageGreaterThanOrEqualTo50() throws InvalidPlayerRoleException {
		//Fill the code here
     assertEquals(1,pObj.findPlayersWithBattingAverageGreaterThanOrEqualTo50().size());
 	}
  	
	//Test the findLowestBowlingEconomy method 
	@Test
	public void test21FindLowestBowlingEconomy() throws InvalidPlayerRoleException{
		//Fill the code here
		assertEquals(1.0,pObj.findLowestBowlingEconomy());

   	 }

	//Test the viewPlayerDetailsByPlayerRole method when the list is empty
	@Test
	public void test22ViewPlayerDetailsByPlayerRoleForEmptyList() throws InvalidPlayerRoleException {
		//Fill the code here
		assertEquals(1,pObj.viewPlayerDetailsByPlayerRole("Bowler").size());
	}
    
	//Test the viewPlayerDetailsPlayerRoleWise method when the list is empty
	@Test
	public void test23ViewPlayerDetailsPlayerRoleWiseForEmptyList()  {
		//Fill the code here
		PlayerAssociation p1=new PlayerAssociation();
		p1.setPlayerList(new ArrayList<Player>());
		assertThrows(InvalidPlayerRoleException.class,()->p1.viewPlayerDetailsPlayerRoleWise());
		
	}
    
	//Test the countTotalNumberOfPlayersForEachPlayerRole method when the list is empty
	@Test
	public void test24TotalCountOfPlayersForEachPlayerRoleForEmptyList() {
		//Fill the code here
		PlayerAssociation p2=new PlayerAssociation();
		p2.setPlayerList(new ArrayList<Player>());
		assertThrows(InvalidPlayerRoleException.class,()->p2.countTotalNumberOfPlayersForEachPlayerRole());
	}
   
	//Test the findPlayersWithBattingAverageGreaterThanOrEqualTo50 method when the list is empty
	@Test
  	public void test25FindPlayersWithBattingAverageGreaterThanOrEqualTo50ForEmptyList() {
    	//Fill the  code here
		PlayerAssociation p3=new PlayerAssociation();
		p3.setPlayerList(new ArrayList<Player>());
		assertThrows(InvalidPlayerRoleException.class,()->p3.findPlayersWithBattingAverageGreaterThanOrEqualTo50());
	}
    
    
	//Test the findLowestBowlingEconomy method when the list is empty
	@Test
  	public void test26FindLowestBowlingEconomyForEmptyList() {	 	
		PlayerAssociation p4=new PlayerAssociation();
		p4.setPlayerList(new ArrayList<Player>());
		assertThrows(InvalidPlayerRoleException.class,()->p4.findLowestBowlingEconomy());
    	//Fill the  code here

	}
	
	
}

    
  
