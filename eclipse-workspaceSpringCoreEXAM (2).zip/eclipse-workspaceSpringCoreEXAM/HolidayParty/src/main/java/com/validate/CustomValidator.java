package com.validate;

import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.model.RegistrationBean;


public class CustomValidator implements Validator{

	
	public void validate(Object arg0, Errors arg1) {
		
		
	
	}

	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
