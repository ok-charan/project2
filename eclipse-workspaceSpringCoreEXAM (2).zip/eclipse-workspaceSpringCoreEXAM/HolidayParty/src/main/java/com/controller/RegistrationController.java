package com.controller;

import org.springframework.validation.BindingResult;
import com.model.RegistrationBean;
import com.validate.CustomValidator;


public class RegistrationController {

	
	private CustomValidator custValidator;
	
	public String registerPage(RegistrationBean  registrationBean, 
			BindingResult result) {
		return null;
	}
	
	
	
	public String performRegistration( RegistrationBean  registrationBean, 
			BindingResult result) {
		
		return null;
	}
}
