package com.spring.exception;

public class UnavailableArtFormException extends Exception {

	public UnavailableArtFormException(String msg) {
		// Fill the code
		super(msg);
	}
}
