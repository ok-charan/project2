package com.spring.model;

public interface Organization {
	  
  void calculateOrganizationRevenue(double totalFees) ;
 
}
