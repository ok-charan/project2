package com.spring.model;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class
//Use appropriate annotation for scope
@Component
@Scope("prototype")
public class ArtForm implements Organization {

	private String artForm;

	private int noOfStudents;
	private int noOfClassesPerMonth;
	private double organizationRevenue;

	// use appropriate annotation
     @Value("#{${artDetails.map}}")
	private Map<String, Double> artDetails;

	// use appropriate annotation
     @Value("#{${percentage}}")
	private double percentage;

	public String getArtForm() {
		return artForm;
	}

	public void setArtForm(String artForm) {
		this.artForm = artForm;
	}

	public int getNoOfStudents() {
		return noOfStudents;
	}

	public void setNoOfStudents(int noOfStudents) {
		this.noOfStudents = noOfStudents;
	}

	public int getNoOfClassesPerMonth() {
		return noOfClassesPerMonth;
	}

	public void setNoOfClassesPerMonth(int noOfClassesPerMonth) {
		this.noOfClassesPerMonth = noOfClassesPerMonth;
	}

	public double getOrganizationRevenue() {
		return organizationRevenue;
	}

	public void setOrganizationRevenue(double organizationRevenue) {
		this.organizationRevenue = organizationRevenue;
	}

	public Map<String, Double> getArtDetails() {
		return artDetails;
	}

	public void setArtDetails(Map<String, Double> artDetails) {
		this.artDetails = artDetails;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	@Override
	public void calculateOrganizationRevenue(double totalFees) {
		// Fill the code
		double d=(totalFees*percentage)/100;
		setOrganizationRevenue(d);
		
		System.out.println("The total monthly revenue from "+getArtForm() +" is $"+d);
	}
}
