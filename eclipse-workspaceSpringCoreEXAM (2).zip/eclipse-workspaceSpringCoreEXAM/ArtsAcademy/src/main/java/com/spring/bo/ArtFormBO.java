package com.spring.bo;

import org.springframework.stereotype.Component;

import com.spring.exception.UnavailableArtFormException;
import com.spring.model.ArtForm;

//use appropriate annotation to make this class as component class
@Component
public class ArtFormBO {

	public double calculateTotalFees(ArtForm artFormObj) throws UnavailableArtFormException {
		double totalFees = 0;
		
		if(artFormObj.getArtForm().equalsIgnoreCase("Dance")) {
			totalFees=artFormObj.getNoOfStudents()*artFormObj.getNoOfClassesPerMonth()*artFormObj.getArtDetails().get("Dance");
		}
		
		else if(artFormObj.getArtForm().equalsIgnoreCase("Music")) {
			totalFees=artFormObj.getNoOfStudents()*artFormObj.getNoOfClassesPerMonth()*artFormObj.getArtDetails().get("Music");
		}
		else {
			throw new UnavailableArtFormException("This art form is not available");
		}

	
		return totalFees;
	}
}
