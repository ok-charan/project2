package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.spring.bo.ArtFormBO;
import com.spring.exception.UnavailableArtFormException;
import com.spring.model.ArtForm;

//use appropriate annotation to make this class as component class
@Component
@Service
public class ArtFormService {

	private ArtFormBO artFormBO;

	// use appropriate annotation
	@Autowired
	public ArtFormService(ArtFormBO artFormBO) {
		super();
		this.artFormBO = artFormBO;
	}

	public ArtFormBO getArtFormBO() {
		return artFormBO;
	}

	public void setArtFormBO(ArtFormBO artFormBO) {
		this.artFormBO = artFormBO;
	}

	public void calculateTotalFees(ArtForm artFormObj) throws UnavailableArtFormException {

		// Fill the code
//	double d=	artFormBO.calculateTotalFees(artFormObj);
//	String name = artFormObj.getArtForm();
//	boolean check=true;
//     double map=0;
//	for(var v:artFormObj.getArtDetails().entrySet()) {
//		map+=v.getValue().equals(name)
//		if(v.getKey().equals(name)){
//			
//			check=true;
//			break;
//		}else
//		{
//			check=false;
//		}
//		if(check==true) {
//			artFormObj.calculateOrganizationRevenue(d);
//		}else
//		{
//		  throw new UnavailableArtFormException("No profit to calculate organizationRevenue");
//		}
//	}
		
		double d=artFormBO.calculateTotalFees(artFormObj);
		String form=artFormObj.getArtForm();
		boolean check=true;
		double map=0;
		for(var v:artFormObj.getArtDetails().entrySet()) {
			if(v.getKey().equals(form)) {
			map+=v.getValue();
			check=true;
			break;
			}
			else
			{
				check=false;
			}
			
		}
if(check==true) {
	artFormObj.calculateOrganizationRevenue(d);
}else
{
	throw new UnavailableArtFormException("no profit to calculate organizationRevenue");
}
	}
}