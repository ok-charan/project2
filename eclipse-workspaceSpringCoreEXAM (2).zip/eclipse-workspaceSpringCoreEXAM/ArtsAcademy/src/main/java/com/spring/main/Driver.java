package com.spring.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.UnavailableArtFormException;
import com.spring.model.ArtForm;
import com.spring.service.ArtFormService;

public class Driver {

	public static void main(String[] args) {
		// Fill the code
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		ArtForm art = context.getBean(ArtForm.class);
		Scanner scan = new Scanner(System.in);
		System.out.println("Art form 1 details");
		System.out.println("Enter the art form");
		String form = scan.nextLine();
		System.out.println("Enter the number of students");
		int numofclass = scan.nextInt();
		System.out.println("Enter the number of classes in a month");
		int numofmonth = scan.nextInt();
		scan.nextLine();

		art.setArtForm(form);
		art.setNoOfStudents(numofmonth);
		art.setNoOfClassesPerMonth(numofclass);

		ArtForm art1 = context.getBean(ArtForm.class);
		System.out.println("Art form 2 details");
		System.out.println("Enter the art form");
		String formnew = scan.nextLine();
		System.out.println("Enter the art form");
		int numofclassnew = scan.nextInt();
		System.out.println("Enter the number of classes in a month");
		int numofmonthnew = scan.nextInt();

		art1.setArtForm(formnew);
		art1.setNoOfStudents(numofclassnew);
		art1.setNoOfClassesPerMonth(numofmonthnew);

		ArtFormService service = context.getBean(ArtFormService.class);

		try {
			service.calculateTotalFees(art);

		} catch (UnavailableArtFormException e) {
			System.out.println(e.getMessage());
		}

		try {
			service.calculateTotalFees(art1);

		} catch (UnavailableArtFormException e) {
			System.out.println(e.getMessage());
		}
	}

}
