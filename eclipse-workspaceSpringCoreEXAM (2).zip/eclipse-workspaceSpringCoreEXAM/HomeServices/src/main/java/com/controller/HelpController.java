package com.controller;

import java.util.Map;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import com.model.HelperBean;
import com.service.HelperService;



public class HelpController {
	
	
	private HelperService helpService;
	
	
	public String showPage( HelperBean helperBean, 
			BindingResult result) {
		
		return null;

	}
	
	
	public  Map<String, String> buildState(){
		return null;

	}


	
	public String calculateTotalCost(HelperBean helperBean, 
			ModelMap model,BindingResult result) {
		
		return null;
	}
	
	
	
	
}
