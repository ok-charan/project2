package com.service;
import com.model.HelperBean;

public class HelperService {
	
	
	public double calculateTotalCost(HelperBean helperBean)
	{
		
		return 0.0;
		
		
	}

}
