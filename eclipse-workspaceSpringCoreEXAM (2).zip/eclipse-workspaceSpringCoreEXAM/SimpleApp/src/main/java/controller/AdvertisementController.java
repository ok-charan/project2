package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import model.Advertisement;

@Controller
public class AdvertisementController {
	
	@RequestMapping(value="/getdetails" ,method=RequestMethod.GET)
	String getAdvertisementpage(Advertisement aobj)
	{
		return "advertisement";
	}
	
	@RequestMapping("/display")
	String displayAdvertisementDetails(@ModelAttribute("advertisement") Advertisement aobj)
	{
		return "success";
	}
}
