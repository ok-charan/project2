package com.test;
 
import com.exception.InvalidOnlineOrderException;
import com.model.OnlineOrder;
import com.util.EStore;
 
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.List;
 
public class EStoreTest {
    private static EStore bObj;
 
    @BeforeAll
    public static void setUp() throws Exception {
        // Create few objects for OnlineOrder class and add to a list.
        // Set that list to the onlineOrderList using the setOnlineOrderList method in EStore
        bObj = new EStore();
        List<OnlineOrder> onlineOrderList = new ArrayList<>();
        onlineOrderList.add(new OnlineOrder(1,"Sharan","Laptop","Electronics",2,"FastDelivery",50000));
        onlineOrderList.add(new OnlineOrder(2,"Basava","OnePlus","Mobiles",4,"NormalDelivery",30000));
        onlineOrderList.add(new OnlineOrder(3,"Virat","Rice","Essentials",6,"FastDelivery",1200));
        onlineOrderList.add(new OnlineOrder(4,"Dhoni","T-Shirt","Fashion",8,"NormalDelivery",500));
        
        bObj.setOnlineOrderList(onlineOrderList);
    }
 
    // Test the validateItemType method when the item type is Electronics
    @Test
    public void test11ValidateItemTypeWhenElectronics() throws InvalidOnlineOrderException {
        assertTrue(bObj.validateItemType("Electronics"));
    }
 
    // Test the validateItemType method when the item type is Mobiles
    @Test
    public void test12ValidateItemTypeWhenMobiles() throws InvalidOnlineOrderException {
        assertTrue(bObj.validateItemType("Mobiles"));
    }
 
    // Test the validateItemType method when the item type is Essentials
    @Test
    public void test13ValidateItemTypeWhenEssentials() throws InvalidOnlineOrderException {
       assertTrue(bObj.validateItemType("Essentials"));
    }
 
    // Test the validateItemType method when the item type is Fashion
    @Test
    public void test14ValidateItemTypeWhenFashion() throws InvalidOnlineOrderException {
        assertTrue(bObj.validateItemType("Fashion"));
    }
 
    // Test the validateItemType method when the item type is Invalid
    @Test
    public void test15ValidateItemTypeWhenInvalid() {
       
    	assertThrows(InvalidOnlineOrderException.class,()-> bObj.validateItemType(""));
   }
 
 
    // Test the viewOnlineOrdersByOrderId method when the value is valid
    @Test
    public void test16ViewOnlineOrdersByOrderIdWhenValid() throws InvalidOnlineOrderException {
        OnlineOrder order = bObj.viewOnlineOrdersByOrderId(1);
//        assert (order != null);
        assert(order.getOrderId()==1);
//        assert ("John Doe".equals(order.getCustomerName()));
//        assert ("Laptop".equals(order.getItemName()));
//        assert ("Electronics".equals(order.getItemType()));
//        assert (order.getQuantity() == 1);
//        assert ("Express".equals(order.getDeliveryType()));
//        assert (order.getCost() == 1200.0);
    }
 
    // Test the viewOnlineOrdersByOrderId method when the value is Invalid
    @Test
    public void test17ViewOnlineOrdersByOrderIdWhenInvalid() {
        try 
        {
        	bObj.viewOnlineOrdersByOrderId(10);
        	fail("Order Id is invalid");
        }
        catch(InvalidOnlineOrderException e)
        {
        	assert(true);
        }

    }
}