package com.exception;

public class InvalidFoodOrderException extends Exception {

	public InvalidFoodOrderException(String message) {
		super(message);
	}

}
