package com.test;
 
import com.model.FoodOrder;

import com.exception.InvalidFoodOrderException;

import com.util.FoodShop;
 
import java.util.ArrayList;

import java.util.Arrays;

import java.util.List;

import java.util.Map;
 
import org.junit.jupiter.api.BeforeAll;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
 
public class FoodShopTest {
 
    private static FoodShop bObj;
 
    @BeforeAll

    public static void setUp() throws Exception {

        // Create a few objects for FoodOrder class and add them to a list

        // Set that list to the foodOrderList using the setFoodOrderList method in FoodShop

//        List<FoodOrder> foodOrders = new ArrayList<>();
//
//        foodOrders.add(new FoodOrder(1, "John", "Pizza", "NonVeg", 2, "FastDelivery", 20.0));
//
//        foodOrders.add(new FoodOrder(2, "Alice", "Salad", "Veg", 1, "NormalDelivery", 10.0));
//
//        foodOrders.add(new FoodOrder(3, "Bob", "Burger", "NonVeg", 3, "FastDelivery", 30.0));
    	
    	List<FoodOrder> foodOrderList = new ArrayList<>();
    	foodOrderList.add(new FoodOrder(1,"Sharan","Edly","Veg",4,"FastDelivery",50.0));
    	foodOrderList.add(new FoodOrder(2,"Basava","FishFry","NonVeg",6,"NormalDelivery",200));
 
        bObj = new FoodShop();
        bObj.setFoodOrderList(foodOrderList);

     //   bObj.setFoodOrderList(foodOrders);

    }
 
    // Test the viewFoodOrdersByFoodType method

    @Test

    public void test11ViewFoodOrdersByFoodType() throws InvalidFoodOrderException {

//        List<FoodOrder> vegOrders = bObj.viewFoodOrdersByFoodType("Veg");
//
//        assertEquals(1, vegOrders.size());
//
//        assertEquals("Alice", vegOrders.get(0).getCustomerName());
    	List<FoodOrder> l=bObj.viewFoodOrdersByFoodType("Veg");
    	assertEquals(l,bObj.viewFoodOrdersByFoodType("Veg"));
    }
 
    // Test the viewFoodOrdersByFoodTypeWise method

   @Test

    public void test12ViewFoodOrdersByFoodTypeWise() throws InvalidFoodOrderException {
//
//        Map<String, List<FoodOrder>> ordersByFoodType = bObj.viewFoodOrdersByFoodTypeWise();
//
//        assertEquals(2, ordersByFoodType.size());
//
//        assertTrue(ordersByFoodType.containsKey("Veg"));
//
//        assertTrue(ordersByFoodType.containsKey("NonVeg"));
//
//        assertEquals(1, ordersByFoodType.get("Veg").size());
//
//        assertEquals(2, ordersByFoodType.get("NonVeg").size());
    	
    	Map<String,List<FoodOrder>> mp=bObj.viewFoodOrdersByFoodTypeWise();
    	assertEquals(mp,bObj.viewFoodOrdersByFoodTypeWise());

    }
 
    // Test the viewFoodOrdersByFoodType method when the list is empty

    @Test

    public void test13ViewFoodOrdersByFoodTypeForEmptyList() {
//
//        FoodShop emptyShop = new FoodShop();
//
//        assertThrows(InvalidFoodOrderException.class, () -> emptyShop.viewFoodOrdersByFoodType("Veg"));

    	FoodShop f=new FoodShop();
    	assertThrows(InvalidFoodOrderException.class,()-> f.viewFoodOrdersByFoodType(" "));
    }
 
    // Test the viewFoodOrdersByFoodTypeWise method when the list is empty

    @Test

    public void test14ViewFoodOrdersByFoodTypeWiseForEmptyList() {

//        FoodShop emptyShop = new FoodShop();
//
//        assertThrows(InvalidFoodOrderException.class, () -> emptyShop.viewFoodOrdersByFoodTypeWise());

    	FoodShop ff=new FoodShop();
//    	try
//    	{
//    		ff.viewFoodOrdersByFoodTypeWise();
//    		fail("List is empty");
//    	}
//    	catch(InvalidFoodOrderException e)
//    	{
//    		assert(true);
//    	}
    	
    	assertThrows(InvalidFoodOrderException.class,()-> ff.viewFoodOrdersByFoodTypeWise());
    }

}
