package com.test;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
 
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;
 
import com.model.Employee;
import com.service.EmployeeService;
import com.repo.EmployeeRepo;
 
@ExtendWith(MockitoExtension.class)
@ExtendWith(MockitoExtension.class)
public class EmployeeTest {
 
	@Mock
	EmployeeRepo repo;
 
	@InjectMocks
	EmployeeService service;
 
	// Test the addEmployee method in EmployeeService class
	@Test
	public void test1AddEmployee() {
		Employee employee = new Employee(1, "John Doe", "john.doe@example.com", 50000.0);
		List empList = new ArrayList<>();
		when(repo.addEmployeeToList(employee)).thenReturn(empList.size() + 1);
 
		int size = service.addEmployee(employee);
 
		assertEquals(1, size);
	}
 
	// Test the deleteEmployee method in EmployeeService class
	@Test
	public void test2DeleteEmployee() {
		Employee employee = new Employee(1, "John Doe", "john.doe@example.com", 50000.0);
		doNothing().when(repo).deleteEmployeeFromList(employee);
 
		service.deleteEmployee(employee);
 
		verify(repo, times(1)).deleteEmployeeFromList(employee);
	}
 
	// Test the fetchEmployeeById method in EmployeeService class for a valid
	// employeeId
	@Test
	public void test3FetchEmployeeByEmployeeId() {
		Employee employee = new Employee(1, "John Doe", "john.doe@example.com", 50000.0);
		when(repo.getEmployeeByEmployeeId(1)).thenReturn(employee);
 
		Employee fetchedEmployee = service.fetchEmployeeById(1);
 
		assertEquals(employee, fetchedEmployee);
	}
 
	// Test the fetchEmployeeById method in EmployeeService class for an invalid
	// employeeId
	@Test
	public void test4FetchEmployeeByEmployeeIdWhenNull() {
		when(repo.getEmployeeByEmployeeId(100)).thenReturn(null);
 
		assertThrows(NullPointerException.class, () -> {
			service.fetchEmployeeById(100);
		});
	}
 
	// Test the fetchEmployee method in EmployeeService class
	@Test
	public void test5FetchEmployee() {
		List empList = new ArrayList<>();
		empList.add(new Employee(1, "John Doe", "john.doe@example.com", 50000.0));
		empList.add(new Employee(2, "Jane Smith", "jane.smith@example.com", 60000.0));
 
		when(repo.getEmployee()).thenReturn(empList);
 
		List fetchedEmployees = service.fetchEmployee();
 
		assertEquals(empList.size(), fetchedEmployees.size());
		assertEquals(empList, fetchedEmployees);
	}
}
