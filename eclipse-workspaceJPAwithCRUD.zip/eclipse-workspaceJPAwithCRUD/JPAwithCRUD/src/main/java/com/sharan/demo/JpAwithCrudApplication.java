package com.sharan.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpAwithCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpAwithCrudApplication.class, args);
	}

}
