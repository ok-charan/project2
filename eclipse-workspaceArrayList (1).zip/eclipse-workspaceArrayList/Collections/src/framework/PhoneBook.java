package framework;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
public class PhoneBook {
private List<Contact> phoneBook=new ArrayList<>();

public List<Contact> getPhoneBook() {
	return phoneBook;
}

public void setPhoneBook(List<Contact> phoneBook) {
	this.phoneBook = phoneBook;
}
public void addContact(Contact contactObj)
{
	phoneBook.add(contactObj);
}
public List<Contact> viewAllContacts()
{
	return phoneBook;
}
public Contact viewContactGivenPhone(long phoneNumber)
{
	for(Contact e : phoneBook) {
		if(e.getPhoneNumber()==phoneNumber) {
			return e;
		}
	}
	return null;
}
public boolean removeContact(long phoneNumber)
{
	for(Contact e : phoneBook) {
		if(e.getPhoneNumber()==phoneNumber) {
			phoneBook.remove(e);
			return true;
		}
	}
	return false;
}
}
