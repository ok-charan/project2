package framework;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		boolean flag = true;
		PhoneBook add = new PhoneBook();

		while (flag) {
			Scanner sc = new Scanner(System.in);

			System.out.println("Menu");
			System.out.println(
					"1.Add Contact\n2.Display all contacts\n3.Search contact by phone\n4.Remove contact\n5.Exit");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {

			case 1:
				System.out.println("Add a Contact:");

				System.out.println("Enter the First Name: ");
				String fristName = sc.next();

				System.out.println("Enter the Last Name: ");
				String lastName = sc.next();

				System.out.println("Enter the Phone No: ");
				Long phoneNo = sc.nextLong();

				String numberCheck = phoneNo.toString();

				System.out.println("Enter the Email: ");
				String email = sc.next();

				Contact cc = new Contact(fristName, lastName, phoneNo, email);
				add.addContact(cc);

				break;
			// case2

			case 2:
				System.out.println("The contact in the List are:");

				List<Contact> li = add.viewAllContacts();
				if (li.size() > 0) {
					for (Contact e : li) {

						System.out.println("First Name:" + e.getFirstName());
						System.out.println("Last Name:" + e.getLastName());
						System.out.println("Phone No:" + e.getPhoneNumber());
						System.out.println("Email:" + e.getEmailId());
					}
				} else {
					System.out.println("List is found empty");
				}
				break;

			case 3:
				System.out.print("Enter the Phone number to search contact:");
				long searchNo = sc.nextLong();

				Contact findNo = add.viewContactGivenPhone(searchNo);
				if (findNo != null) {
					System.out.println("First Name:" + findNo.getFirstName());
					System.out.println("Last Name:" + findNo.getLastName());
					System.out.println("Phone No:" + findNo.getPhoneNumber());
					System.out.println("Email:" + findNo.getEmailId());

				} else {
					System.out.println("Contact not found");
				}
				break;
			case 4:
				System.out.println("Enter the Phone number to remove :");
				long phoneRemove = sc.nextLong();
				System.out.println("Do you want to remove the contact (Y/N):");
				String opinion = sc.next();
				if (opinion.equalsIgnoreCase("y")) {
					if (add.removeContact(phoneRemove)) {
						System.out.println("The contact is successfully deleted.");
					} else {
						System.out.println("Contact not found");
					}
				}

				break;
			case 5:

				flag = false;
				break;

			default:
				System.out.println("Your enter worng number");
			}

		}

	}
}

