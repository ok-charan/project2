package com.test;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
 
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
import com.exception.InvalidConsumerException;
import com.model.Consumer;
import com.util.CreditScoreReport;
 
public class CreditScoreReportTest
{
	private static CreditScoreReport csrObj;
	
	@BeforeAll
	
	public static  void setUp() throws Exception
	{
	
		
		//Create few  objects for Consumer class and add to a list.
		//Set that list to the consumerList, using the setConsumerList method in CreditScoreReport class
          csrObj=new CreditScoreReport();
          
          List<Consumer> consumerList=new ArrayList<>();
          consumerList.add(new Consumer("1","Sharan","1999-02-01","12345678",10000,350));
          consumerList.add(new Consumer("2","Basava","1999-09-01","12312312",20000,550));
          consumerList.add(new Consumer("3","Virat","1992-011-05","12121212",30000,750));
          consumerList.add(new Consumer("4","Kohli","1990-010-15","87435373",40000,800));
		
          csrObj.setConsumerList(consumerList);
//		Consumer c1=new Consumer("1", "John Doe", "1990-01-01", "123456789", 5000.0, 750);
//		Consumer c2=new Consumer("2", "Jane Smith", "1985-05-15", "987654321", 6000.0, 850);
//		Consumer c3=new Consumer("3", "John Doe", "1991-09-01", "134578845", 8000.0, 700);
//		Consumer c4=new Consumer("4", "Jane Smith", "1988-07-15", "975645396", 9000.0, 900);
//		
//		List<Consumer> cc=new ArrayList<>();
//		
//		cc.add(c1);
//		cc.add(c2);
//		cc.add(c3);
//		cc.add(c4);
//		
//		
//		csrObj.setConsumerList(cc);
	
	    
	}
	
	// Test totalConsumerCountForEachCreditScoreRange method
	@Test
	public void test11TotalConsumerCountForEachCreditScoreRange() throws InvalidConsumerException
	{	 	  	  	 		  	     	      	 	
		// Fill the code here
		Map<Integer,Integer> mp=csrObj.totalConsumerCountForEachCreditScoreRange();
		//System.out.println(mp.toString());
		//assertEquals(4,mp.size());
		
		assertEquals(mp,csrObj.totalConsumerCountForEachCreditScoreRange());
		
		
		
		
		//assertEquals(1,mp.get(350));
		
		//Map<Integer, Integer> mp=csrObj.totalConsumerCountForEachCreditScoreRange();
		//assertEquals(3,mp.size());
       //  assertEquals(1,mp.get(750));
        // System.out.println(mp.get(750));
		//System.out.println(mp.size());
//		
//		assertAll(
//			()->assertEquals(1,mp.get(750)),()->assertEquals(1,mp.get(750)),()->assertEquals(1,mp.get(750)),()->assertEquals(1,mp.get(750)));
		
       
 
       
	}
	// Test totalConsumerCountForEachCreditScoreRange method when the list is empty
	@Test
	public void test12TotalConsumerCountForEachCreditScoreRangeForEmptyList()
	{
		// Fill the code here
		
		CreditScoreReport cr=new CreditScoreReport();
		
//        assertThrows(InvalidConsumerException.class, () -> {
//        	cr.totalConsumerCountForEachCreditScoreRange();});
//	
//		try
//		{
//			cr.totalConsumerCountForEachCreditScoreRange();	
//			fail("Consumer List is empty");
//		}
//		catch(InvalidConsumerException e)
//		{
//			assert(true);
//		}
		//csrObj=new CreditScoreReport();
		assertThrows(InvalidConsumerException.class,()-> cr.totalConsumerCountForEachCreditScoreRange());
		
		
	
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 800 to 900
	@Test
	public void test13ViewConsumerReportBasedOnCreditScoreWhenExcellent() throws InvalidConsumerException
	{
		// Fill the code here
	//String report=csrObj.viewConsumerReportBasedOnCreditScore(850);
		//assertEquals("EXCELLENT",report);
		assertEquals("EXCELLENT",csrObj.viewConsumerReportBasedOnCreditScore(800));
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 600 to 799
	@Test
	public void test14ViewConsumerReportBasedOnCreditScoreWhenGood() throws InvalidConsumerException
	{
		// Fill the code here
//		String report=csrObj.viewConsumerReportBasedOnCreditScore(650);
//		assertEquals("GOOD",report);
		assertEquals("GOOD",csrObj.viewConsumerReportBasedOnCreditScore(750));
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 500 to 599
	@Test
	public void test15ViewConsumerReportBasedOnCreditScoreWhenFair() throws InvalidConsumerException
	{
		// Fill the code here
		//assertEquals("FAIR",csrObj.viewConsumerReportBasedOnCreditScore(550));
		assertEquals("FAIR",csrObj.viewConsumerReportBasedOnCreditScore(550));
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 300 to 499
	@Test
	public void test16ViewConsumerReportBasedOnCreditScoreWhenPoor() throws InvalidConsumerException
	{
		// Fill the code here
		//assertEquals("POOR",csrObj.viewConsumerReportBasedOnCreditScore(350));
		assertEquals("POOR",csrObj.viewConsumerReportBasedOnCreditScore(350));
	}
	//Test the viewConsumerReportBasedOnCreditScore method For EmptyList
	@Test
	public void test17ViewConsumerReportBasedOnCreditScoreForEmptyList() throws InvalidConsumerException
	{
		// Fill the code here
		
		CreditScoreReport cr=new CreditScoreReport();
//	        assertThrows(InvalidConsumerException.class,
//	        		() -> assertEquals("",cr.viewConsumerReportBasedOnCreditScore(999))
//	        		);
	        	
		//assertThrows(InvalidConsumerException.class,()-> cr.viewConsumerReportBasedOnCreditScore(905));
		
		assertThrows(InvalidConsumerException.class,()-> cr.viewConsumerReportBasedOnCreditScore(0));
	}
	        
}
	 	  	  	 		  	     	      	 	
 
