package com.exception;

public class InvalidOnlineOrderException extends Exception {

	public InvalidOnlineOrderException(String message) {
		super(message);
	}

}
