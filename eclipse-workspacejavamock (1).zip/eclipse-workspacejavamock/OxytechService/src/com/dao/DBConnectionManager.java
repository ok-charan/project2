//Don't hardcode values in this class, instead read them from database.properties file.
package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionManager {

	private static Connection con = null;

	public static Connection getConnection() throws Exception
	{
	    // Fill the code here
		try 
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oxytech","root","root");
	    
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;	
}
}
	
