package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.model.Laptop;

public class LaptopDAO {
	public static Connection connection= null;

	public int insertLaptopDetails(Laptop laptopObj)  throws Exception {
		
		// Fill the code here
		String query="Insert into laptop values(?,?,?,?,?)";
		try 
		{
			connection=DBConnectionManager.getConnection();
			PreparedStatement pst=connection.prepareStatement(query);
			pst.setString(1, laptopObj.getHardwareId());
			pst.setString(2, laptopObj.getLaptopName());
			pst.setString(3, laptopObj.getRootIssue());
			pst.setString(4, laptopObj.getIssueIntensity());
			pst.setDouble(5, laptopObj.getBillAmount());
			
		int rs=pst.executeUpdate();
			pst.close();
			connection.close();
			
		
			if(rs>0)
			{
				return 1;
			}
			else
			{
				  return -1;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
}
		

	 	  	  		    	  	      	      	 	