/*Test your application by invoking the service methods from the UserInterface class. 
You are free to write your own code in the main method to invoke the business methods 
to check its correctness. UserInterface class is not taken for evaluation. 
*/
package com.client;

import java.util.Scanner;

import com.service.LaptopService;
import com.model.Laptop;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Laptop lapObj = new Laptop();

		LaptopService laptopServiceObj = new LaptopService();
		boolean recordInserted = false;

		System.out.println("Enter the laptop service details");

		System.out.println("Enter hardwareId");
		String hardwareId = sc.next();

		System.out.println("Enter laptopName");
		String laptopName = sc.next();

		System.out.println("Enter rootIssue");
		String rootIssue = sc.next();

		System.out.println("Enter issueIntensity");
		String issueIntensity = sc.next();

		lapObj.setHardwareId(hardwareId);
		lapObj.setLaptopName(laptopName);
		lapObj.setRootIssue(rootIssue);
		lapObj.setIssueIntensity(issueIntensity);

		recordInserted = laptopServiceObj.addLaptopDetails(lapObj);

		if (recordInserted)
			System.out.println("Read valid laptop service record and updated it to the database");
		else
			System.out.println("Failed to add record to the database");
	}
}
