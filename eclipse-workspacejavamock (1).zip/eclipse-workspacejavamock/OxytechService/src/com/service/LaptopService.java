package com.service;

import com.model.Laptop;
import com.dao.LaptopDAO;

public class LaptopService {

	public boolean addLaptopDetails(Laptop lapObj){

		// Fill the code here
		
		return true;
	}
	
	public static double calculateBillAmount(String rootIssue,String issueIntensity)
	{
		// Fill the code here
		double b=0,c=0;
		switch(rootIssue.toUpperCase()) {
		case "SOFTWARE":
			b=2000;
			break;
			
		case "DISPLAY":
			b=5000;
			break;
			
		case "KEYBOARD":
			b=1000;
			break;
			
		case "SOUND":
			b=800;
			break;
			
		case "KEY":
			b=500;
			break;
		}
		switch(issueIntensity.toUpperCase())
		{
		case "LOW":
			c=b-(b*0.05);
			break;
			
		case "MID":
			c=b+(b*0.05);
			break;
			
		case "HIGH":
			c=b+(b*0.1);
			break;
		}
		return c;
	}

}

