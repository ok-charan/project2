package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext con = new ClassPathXmlApplicationContext("beans.xml");

		Person p1 = con.getBean(Person.class);
		p1.setName("person1");
		p1.setAge(24);

		

		Person p2 = con.getBean(Person.class);
		p2.setName("person2");
		p2.setAge(35);

		System.out.println(p1.getName());
		System.out.println(p1.getAge());
		System.out.println(p2.getName());
		System.out.println(p2.getAge());
	}

}
