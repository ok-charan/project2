package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import com.exception.InvalidLaptopException;
import com.util.ApplicationUtil;
import com.model.Laptop;

public class LaptopDAO {
	public static Connection connection= null;
	//public static PreparedStatement ps=null;

	public int insertServiceList(List<Laptop> serviceList)  {
		String sql="Insert into Laptop values(?,?,?,?,?,?)";
		
		// Fill the code here
		try {
			connection=DBConnectionManager.getConnection();
			PreparedStatement ps=connection.prepareStatement(sql);
			for(Laptop l:serviceList) {
				ps.setString(1, l.getHardwareId());
				ps.setString(2, l.getLaptopName());
				ps.setDate(3, ApplicationUtil.utilToSqlDateConverter(l.getReceivedDate()));
				ps.setString(4, l.getRootIssue());
				ps.setString(5,l.getIssueIntensity());
				ps.setDouble(6, l.getBillAmount());
				
				ps.executeUpdate();
			}
			ps.close();
			connection.close();
			return serviceList.size();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
        
         return 0;
	}
}
	 	  	  		    	  	      	      	 	