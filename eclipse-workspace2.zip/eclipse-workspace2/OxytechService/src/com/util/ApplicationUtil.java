package com.util;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.exception.InvalidLaptopException;

public class ApplicationUtil {

	public static List<String> extractDetails(String[] input) {
	    List<String> stringList = new ArrayList<String>();

	    // FILL THE CODE HERE
	    	
	   	 return stringList;
	}


	public static boolean validateLaptopName(String laptopName) throws InvalidLaptopException{
		
		// FILL THE CODE HERE
		
	    	return false;
	}

	public static java.util.Date stringToDateConverter(String stringDate) {
		
		// FILL THE CODE HERE
		
	    	return null;
	}
public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
	
	    // FILL THE CODE HERE
	    return null;
	}	 
	 	  	  		    	  	      	      	 	

}