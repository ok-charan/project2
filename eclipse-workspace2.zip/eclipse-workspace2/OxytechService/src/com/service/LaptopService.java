package com.service;
import java.util.ArrayList;
import java.util.List;

import com.model.Laptop;
import com.util.ApplicationUtil;

public class LaptopService {

	public static List <Laptop> buildServiceList(List <String> serviceRecords) {

		List <Laptop> objectList = new ArrayList<Laptop>();
		
		// FILL THE CODE HERE
		
		return objectList;
	}

	public boolean addServiceList(String[] input)	{

		// FILL THE CODE HERE
		
		return false;
	}
	
	public static double calculateBillAmount(String rootIssue,String issueIntensity)
	{
		// FILL THE CODE HERE 
		
		return -1;
	}

}

