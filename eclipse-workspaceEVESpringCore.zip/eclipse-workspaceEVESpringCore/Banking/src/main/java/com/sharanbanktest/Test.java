package com.sharanbanktest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sharanbank.BankAccount;
import com.sharanbank.controller.BankAccountcontroller;
public class Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        BankAccountcontroller controller = context.getBean("bankAccountController",BankAccountcontroller.class);
		
		System.out.println("Deposit 500 into account 1: " + controller.deposit(1, 500));
        System.out.println("Withdraw 200 from account 1: " + controller.withdraw(1, 200));
        System.out.println("Balance of account 1: " + controller.getBalance(1));
        System.out.println("Fund transfer 300 from account 1 to account 2: " + controller.fundTransfer(1, 2, 300));
        System.out.println("Balance of account 1: " + controller.getBalance(1));
        System.out.println("Balance of account 2: " + controller.getBalance(2));

	}

}
