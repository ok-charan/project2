package com.sharanbank.repository;
import java.util.HashMap;
import java.util.Map;

import com.sharanbank.BankAccount;
public class BankAccountRepositoryImpl implements BankAccountRepository {
Map<Long,BankAccount> map;
	

	public BankAccountRepositoryImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankAccountRepositoryImpl(Map<Long, BankAccount> map) {
		super();
		this.map = map;
	}

	public Map<Long, BankAccount> getMap() {
		return map;
	}

	public void setMap(Map<Long, BankAccount> map) {
		this.map = map;
	}

	@Override
	public double getBalance(long accountId) {
		// TODO Auto-generated method stub

		BankAccount account = map.get(accountId);
        return account != null ? account.getAccountBalance() : 0;
	}

	@Override
	public double updateBalance(long accountId, double newBalance) {
		// TODO Auto-generated method stub
		BankAccount account = map.get(accountId);
        if (account != null) {
            account.setAccountBalance(newBalance);
            return newBalance;
        }
        return 0;
	}

}
