package com.sharanbank.service;

import com.sharanbank.repository.BankAccountRepositoryImpl;

public class BankAccountServiceImpl implements BankAccountService{
private BankAccountRepositoryImpl bankAccountRepositoryImpl;
	
	
	public BankAccountServiceImpl() {}

    
    public BankAccountServiceImpl(BankAccountRepositoryImpl bankAccountRepositoryImpl) {
        this.bankAccountRepositoryImpl = bankAccountRepositoryImpl;
    }

    
    public void setBankAccountRepository(BankAccountRepositoryImpl bankAccountRepositoryImpl) {
        this.bankAccountRepositoryImpl = bankAccountRepositoryImpl;
    }
	
	@Override
	public double withdraw(long accountId, double balance) {
		// TODO Auto-generated method stub
		double currentBalance = bankAccountRepositoryImpl.getBalance(accountId);
        if (currentBalance >= balance) {
            return bankAccountRepositoryImpl.updateBalance(accountId, currentBalance - balance);
        }
        return currentBalance;
	
	}

	@Override
	public double deposit(long accountId, double balance) {
		// TODO Auto-generated method stub
		double currentBalance = bankAccountRepositoryImpl.getBalance(accountId);
        return bankAccountRepositoryImpl.updateBalance(accountId, currentBalance + balance);
	}

	@Override
	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return bankAccountRepositoryImpl.getBalance(accountId);
	}

	@Override
	public boolean fundTransfer(long fromAccount, long toAccount, double amount) {
		// TODO Auto-generated method stub
		double fromBalance = bankAccountRepositoryImpl.getBalance(fromAccount);
        if (fromBalance >= amount) {
            double toBalance = bankAccountRepositoryImpl.getBalance(toAccount);
            bankAccountRepositoryImpl.updateBalance(fromAccount, fromBalance - amount);
            bankAccountRepositoryImpl.updateBalance(toAccount, toBalance + amount);
            return true;
        }
        return false;
    }
	

}
