package com.sharan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
 
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
 
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 

 
public class Testing {
 
	
	ApplicationContext con = new ClassPathXmlApplicationContext("beans.xml");
	Question que = con.getBean("listQuestion",Question.class);
	@Test
	public void checkByQuestionId() {
		assertEquals(1, que.getQuestionId());
	}
	@Test
	public void checkByQuestion() {
		assertEquals("which is your favorite game?", que.getQuestion());
	}
	@Test
	public void checkByListAnswer() {
		List<String> l=Arrays.asList("Cricket","Football","Tennis");
		assertEquals(l, que.getAnswers().getListname());
	}
	@Test
	public void checkBySetAnswer() {
		Set<String> s=Set.of("Cricket","Football","Tennis");
		assertEquals(s,que.getAnswers().getSetname() );
	}
	@Test
	public void checkByMapAnswer() {
//		Map<Integer, String> map = new HashMap<Integer, String>();
//		map.put(1,"cricket");
		assertEquals("Cricket",que.getAnswers().getMapname().get(1));
	}
}
