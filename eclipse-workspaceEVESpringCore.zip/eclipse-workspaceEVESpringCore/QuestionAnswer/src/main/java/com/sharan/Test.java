package com.sharan;

import javax.management.InvalidApplicationException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
		
				Question que1 = context.getBean("listQuestion", Question.class);
//				Question que2 = context.getBean("setQuestion",Question.class);
//				Question que3 = context.getBean("mapQuestion",Question.class);
		 
//				System.out.println(que1.getQuestion());
//				System.out.println(que1.getAnswers().getMapname());
//				System.out.println(que2.getQuestion());
//				System.out.println(que2.getAnswers().getSetname());
//				System.out.println(que3.getQuestion());
//				System.out.println(que3.getAnswers().getListname());
		 
				System.out.println(que1);
			}

	}


