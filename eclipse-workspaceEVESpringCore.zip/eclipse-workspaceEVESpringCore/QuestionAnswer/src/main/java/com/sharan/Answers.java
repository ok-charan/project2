package com.sharan;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Answers {
	private List<String> listname;
	private Set<String> setname;
	private Map<Integer,String> mapname;
 
	public Answers() {
		super();
	}

	public Answers(List<String> listname, Set<String> setname, Map<Integer, String> mapname) {
		super();
		this.listname = listname;
		this.setname = setname;
		this.mapname = mapname;
	}
	public List<String> getListname() {
		return listname;
	}
	public void setListname(List<String> listname) {
		this.listname = listname;
	}
	public Set<String> getSetname() {
		return setname;
	}
	public void setSetname(Set<String> setname) {
		this.setname = setname;
	}
	public Map<Integer, String> getMapname() {
		return mapname;
	}
	public void setMapname(Map<Integer, String> mapname) {
		this.mapname = mapname;
	}
 
 
	@Override
	public String toString() {
		return "Answer [listname=" + listname + ", setname=" + setname + ", mapname=" + mapname + "]";
	}
}
