package com.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTest {

	@Test
	public void test() {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Customer c=context.getBean("customerObj1",Customer.class);
		//Customer c2=context.getBean("customerObj2",Customer.class);
		
		assertEquals(1,c.getCustomerId());
		assertEquals("Sharan",c.getCustomerName());
		assertEquals(9008190081l,c.getCustomerContact());
		assertEquals("Mustur",c.getAddress().getStreet());
		assertEquals("Bengaluru",c.getAddress().getCity());
		assertEquals("Karnataka",c.getAddress().getState());
		assertEquals(583282,c.getAddress().getZip());
		assertEquals("India",c.getAddress().getCountry());
		
		
	}

}
