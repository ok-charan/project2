package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		Customer c = context.getBean("customerObj1",Customer.class);
		Customer c1 = context.getBean("customerObj2",Customer.class);
		
		System.out.println("CustomerID:"+c.getCustomerId());
		System.out.println("CustomerName:"+c.getCustomerName());
		System.out.println("CustomerContact:"+c.getCustomerContact());
		System.out.println("Street:"+c.getAddress().getStreet());
		System.out.println("City:"+c.getAddress().getCity());
		System.out.println("State:"+c.getAddress().getState());
		System.out.println("Zip:"+c.getAddress().getZip());
		System.out.println("Country:"+c.getAddress().getCountry());
		

	}

}
