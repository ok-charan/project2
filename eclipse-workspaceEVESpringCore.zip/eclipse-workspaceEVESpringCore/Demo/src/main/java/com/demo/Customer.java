package com.demo;

public class Customer {
	private int customerId;
	private String customerName;
	private long customerContact;
	
	private Address address;

	
	
	
	public Customer() {
		super();
	}

	public Customer(int customerId, String customerName, long customerContact, Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerContact = customerContact;
		this.address = address;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(long customerContact) {
		this.customerContact = customerContact;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

//	public void CustomerDetails() {
//		System.out.println("Customer ID:" + customerId);
//		System.out.println("Customer Name:" + customerName);
//		System.out.println("Customer Contact:" + customerContact);
//		System.out.println("Street:" + address.getStreet());
//		System.out.println("City:" + address.getCity());
//		System.out.println("State:" + address.getState());
//	}

}
//customerId, customerName, customerContact, customerAddress.