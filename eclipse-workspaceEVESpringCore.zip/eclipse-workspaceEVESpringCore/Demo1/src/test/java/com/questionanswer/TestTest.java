package com.questionanswer;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestTest {

	@Test
	void test() {
		
	}

}
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
 
import org.junit.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 
import com.spring.Question;
 
class QandATest {
 
	private static Question question;
 
	@BeforeAll
	public static void setUp() {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		question = (Question) context.getBean("qListObj");
 
	}
 
	@Test
	public void testListQuestion() {
		assertEquals("What are first five prime numbers?", question.getQuestion());
	}
 
	@Test
	public void testListQuestionAnswer() {
		List<Integer> list = Arrays.asList(2, 3, 5, 7, 11);
		assertEquals(list, question.getAnswer().getListAnswer());
	}
 