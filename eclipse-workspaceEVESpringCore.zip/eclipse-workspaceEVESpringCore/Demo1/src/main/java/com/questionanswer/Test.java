	package com.questionanswer;
	
	import java.security.KeyStore.Entry;

import org.springframework.context.ApplicationContext;
	import org.springframework.context.support.ClassPathXmlApplicationContext;
	 
	public class Test {
		public static void main(String[] args) {
			ApplicationContext con = new ClassPathXmlApplicationContext("beans.xml");
			Question que1 = con.getBean("qListObj", Question.class);
			 
	       System.out.println(que1.getQuestionId()+"."+que1.getQuestion());
	       System.out.println("A. "+que1.getAnswers()+"."+que1.getAnswers().getListanswers());
	      System.out.println();
	      
	      Question que2 = con.getBean("qSetObj", Question.class);
	      
	      System.out.println(que2.getQuestionId()+"."+que2.getQuestion());
	      System.out.println("A. "+que2.getAnswers().getSetanswers());
	      System.out.println();
	      
	      Question que3 = con.getBean("aMapObj", Question.class);
	      
	      System.out.println(que3.getQuestionId()+"."+que3.getQuestion());
	      System.out.println("A. ");
	      for(java.util.Map.Entry<Integer, String> e : que3.getAnswers().getMapanswers().entrySet()) {
	    	  System.out.println(e.getKey()+"."+e.getValue()+" ");
	    	  System.out.println(" ");
	      }
	      
	      
		}
	}
	 