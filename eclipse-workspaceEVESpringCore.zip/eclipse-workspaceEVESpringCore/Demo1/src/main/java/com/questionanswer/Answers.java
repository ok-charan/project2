package com.questionanswer;

import java.util.List;
import java.util.Map;
import java.util.Set;
 
public class Answers {
	
	private List<String>listanswers;
	
	private Set<String>setanswers;
	
	private Map<Integer,String>mapanswers;

	public List<String> getListanswers() {
		return listanswers;
	}

	public void setListanswers(List<String> listanswers) {
		this.listanswers = listanswers;
	}

	public Set<String> getSetanswers() {
		return setanswers;
	}

	public void setSetanswers(Set<String> setanswers) {
		this.setanswers = setanswers;
	}

	public Map<Integer, String> getMapanswers() {
		return mapanswers;
	}

	public void setMapanswers(Map<Integer, String> mapanswers) {
		this.mapanswers = mapanswers;
	}
 
	
	
}
