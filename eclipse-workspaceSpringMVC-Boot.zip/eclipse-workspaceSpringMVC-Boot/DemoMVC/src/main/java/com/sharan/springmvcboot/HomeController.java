package com.sharan.springmvcboot;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sharan.springmvcboot.model.Alien;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class HomeController {
	@ModelAttribute
	public void modelData(Model m) {
		m.addAttribute("name","Aliens");
	}
	@RequestMapping("/")
	public String home() {
		//System.out.println("home page requested");
		return "index";
	}
//	@RequestMapping("add")
//	public String add(HttpServletRequest req) {
//		int i=Integer.parseInt(req.getParameter("num1"));
//		int j=Integer.parseInt(req.getParameter("num2"));
//		
//		int num3=i+j;
//		HttpSession session=req.getSession();
//		session.setAttribute("num3", num3);
//		
//		return "result.jsp";
//		
//	}
	
//	@RequestMapping("add")
//	public String add(@RequestParam("num1") int i ,@RequestParam("num2")  int j, HttpSession session) {
//		int num3=i+j;
//		session.setAttribute("num3", num3);
//		return "result.jsp";
//		
//	}
	
//	@RequestMapping("add")
//	public ModelAndView add(@RequestParam("num1") int i ,@RequestParam("num2")  int j) {
//		
//		ModelAndView mv=new ModelAndView();
//		mv.setViewName("result.jsp");
//		int num3=i+j;
//		mv.addObject("num3",num3);
//		return mv;
//		
//	}
	
//	@RequestMapping("add")
//	public ModelAndView add(@RequestParam("num1") int i ,@RequestParam("num2")  int j) {
//		
//		ModelAndView mv=new ModelAndView();
//		mv.setViewName("result");
//		int num3=i+j;
//		mv.addObject("num3",num3);
//		return mv;
//		
//	}
//	
	
	
//	@RequestMapping("add")
//	public ModelAndView add(@RequestParam("num1") int i ,@RequestParam("num2")  int j) {
//		
//		ModelAndView mv=new ModelAndView("result");
//		
//		int num3=i+j;
//		mv.addObject("num3",num3);
//		return mv;
//		
//	}
	
//	@RequestMapping("add")
//	public String add(@RequestParam("num1") int i ,@RequestParam("num2")  int j, Model m) {   //we can also use model instead of modelmap
//       int num3=i+j;
//		m.addAttribute("num3",num3);
//		return "result";
//		
//	}
    
//	@RequestMapping("addAlien")
//	public String addAlien(@RequestParam("aid") int aid, @RequestParam("aname") String aname, Model m) {
//		Alien a=new Alien();
//		a.setAid(aid);
//		a.setAname(aname);
//		
//		m.addAttribute("alien",a);
//		return "result";
//		
//	}
	
//	@RequestMapping("addAlien")
//	public String addAlien(@ModelAttribute Alien a, Model m) {
//	
//		m.addAttribute("alien",a);
//		return "result";
//		
//	}
	
//	@RequestMapping("addAlien")
//	public String addAlien(@ModelAttribute("a1") Alien a) {
//
//		return "result";
//		
//	}
	
	@GetMapping("/getAliens")
	public String getAliens(Model m) {
		
		List<Alien> aliens= Arrays.asList(new Alien(101,"Naven"), new Alien(102, "Rose"));
		m.addAttribute("result", aliens);
		return "showAliens";	
		}
	
	@RequestMapping("getAliens/{aid}")
	public String getAliensById(@PathVariable int id) {
		return null;
		
	}
	
	
	
	@PostMapping(value = "addAlien") 
	public String addAlien(@ModelAttribute("a1") Alien a) {

		return "result";
		
	}
	
	
}
