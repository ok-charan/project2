package com.test;
 
import com.exception.InvalidOnlineOrderException;
import com.model.OnlineOrder;
import com.util.EStore;
 
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
 
import static org.junit.jupiter.api.Assertions.fail;
 
import java.util.List;
 
public class EStoreTest {
    private static EStore bObj;
 
    @BeforeAll
    public static void setUp() throws Exception {
        // Create few objects for OnlineOrder class and add to a list.
        // Set that list to the onlineOrderList using the setOnlineOrderList method in EStore
        bObj = new EStore();
        List orderList = List.of(
                new OnlineOrder(1, "John Doe", "Laptop", "Electronics", 1, "Express", 1200.0),
                new OnlineOrder(2, "Jane Smith", "Mobile Phone", "Mobiles", 2, "Standard", 800.0),
                new OnlineOrder(3, "Alice", "Groceries", "Essentials", 3, "Standard", 50.0),
                new OnlineOrder(4, "Bob", "T-shirt", "Fashion", 1, "Express", 25.0)
        );
        bObj.setOnlineOrderList(orderList);
    }
 
    // Test the validateItemType method when the item type is Electronics
    @Test
    public void test11ValidateItemTypeWhenElectronics() throws InvalidOnlineOrderException {
       assert(bObj.validateItemType("Electronics"));
    }
 
    // Test the validateItemType method when the item type is Mobiles
    @Test
    public void test12ValidateItemTypeWhenMobiles() throws InvalidOnlineOrderException {
        assert (bObj.validateItemType("Mobiles"));
    }
 
    // Test the validateItemType method when the item type is Essentials
    @Test
    public void test13ValidateItemTypeWhenEssentials() throws InvalidOnlineOrderException {
        assert (bObj.validateItemType("Essentials"));
    }
 
    // Test the validateItemType method when the item type is Fashion
    @Test
    public void test14ValidateItemTypeWhenFashion() throws InvalidOnlineOrderException {
        assert (bObj.validateItemType("Fashion"));
    }
 
    // Test the validateItemType method when the item type is Invalid
    @Test
    public void test15ValidateItemTypeWhenInvalid() {
        try {
            bObj.validateItemType("InvalidType");
            // If the exception is not thrown, fail the test
            fail("Expected InvalidOnlineOrderException but it wasn't thrown");
        } catch (InvalidOnlineOrderException e) {
            // Exception was thrown, the test passes
            assert (true);
        }
    }
 
 
    // Test the viewOnlineOrdersByOrderId method when the value is valid
    @Test
    public void test16ViewOnlineOrdersByOrderIdWhenValid() throws InvalidOnlineOrderException {
        OnlineOrder order = bObj.viewOnlineOrdersByOrderId(1);
        assert (order != null);
        assert (order.getOrderId() == 1);
        assert ("John Doe".equals(order.getCustomerName()));
        assert ("Laptop".equals(order.getItemName()));
        assert ("Electronics".equals(order.getItemType()));
        assert (order.getQuantity() == 1);
        assert ("Express".equals(order.getDeliveryType()));
        assert (order.getCost() == 1200.0);
    }
 
    // Test the viewOnlineOrdersByOrderId method when the value is Invalid
    @Test
    public void test17ViewOnlineOrdersByOrderIdWhenInvalid() {
        try {
            bObj.viewOnlineOrdersByOrderId(10); // Non-existing order id
            // If the exception is not thrown, fail the test
            fail("Expected InvalidOnlineOrderException but it wasn't thrown");
        } catch (InvalidOnlineOrderException e) {
            // Exception was thrown, the test passes
            assert (true);
        }
    }
 
}